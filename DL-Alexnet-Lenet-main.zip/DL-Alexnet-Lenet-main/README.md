# Reconfigurable activation-based Dense CNN Engine for Embedded-FPGA Application.
This repository consist of LeNet and AlexNet model implementation on fpga board (ZCU104):

1) Pre-trained model has been leverages and done using Python in the Google-Colab & related (.ipynb) file inside Software repository.

2) Basic building blocks of LeNet and AlexNet blocks are provided inside a Hardware repository. Consist of different layers viz. linear, convolution , fully connected layer inside both models. The obtained high-level description of the pre-trained model and later, transform into RTL logic through the HLS process using the Vitis-HLS compiler and the obtained RTL are provided in the RTL and IP integration folder.


NOTE: 1) Each (.ipynb) file consists of software results, driver file and ARM-CPU result. Additionally, all C++ files consist of different AlexNet/LeNet blocks code from scratch.
      2) Pynq overlay file and other driver file also available in (.ipynb) file.

In case of any inconvenience drop a mail to respective email id: m23eev006@iitj.ac.in, yadav.49@iitj.ac.in
